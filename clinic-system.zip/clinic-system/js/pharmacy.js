// Pharmacy Data (sample Ethiopian medicines)
let medicines = [
    { id: 1, name: "Amoxicillin 500mg", category: "antibiotics", price: 85.50, quantity: 150, expiry: "2024-06-30", description: "Broad-spectrum antibiotic" },
    { id: 2, name: "Artemether/Lumefantrine 20/120mg", category: "antimalarial", price: 45.00, quantity: 200, expiry: "2024-09-15", description: "For malaria treatment" },
    { id: 3, name: "Paracetamol 500mg", category: "painkillers", price: 12.75, quantity: 500, expiry: "2025-03-20", description: "Pain reliever and fever reducer" },
    { id: 4, name: "Metformin 500mg", category: "diabetes", price: 32.00, quantity: 120, expiry: "2024-11-30", description: "For type 2 diabetes" },
    { id: 5, name: "Losartan 50mg", category: "hypertension", price: 68.90, quantity: 80, expiry: "2024-08-15", description: "For high blood pressure" },
    { id: 6, name: "Ciprofloxacin 500mg", category: "antibiotics", price: 95.25, quantity: 90, expiry: "2024-05-31", description: "For bacterial infections" },
    { id: 7, name: "Doxycycline 100mg", category: "antibiotics", price: 55.00, quantity: 110, expiry: "2024-07-20", description: "For various bacterial infections" },
    { id: 8, name: "Ibuprofen 400mg", category: "painkillers", price: 18.50, quantity: 300, expiry: "2025-01-10", description: "NSAID pain reliever" },
    { id: 9, name: "Glibenclamide 5mg", category: "diabetes", price: 28.75, quantity: 95, expiry: "2024-10-31", description: "For type 2 diabetes" },
    { id: 10, name: "Hydrochlorothiazide 25mg", category: "hypertension", price: 42.00, quantity: 70, expiry: "2024-12-15", description: "Diuretic for high blood pressure" }
];

let cart = [];

// Initialize pharmacy page
function initializePharmacyPage() {
    loadMedicinesTable();
    setupMedicineForm();
    setupCart();

    // Search functionality
    document.getElementById('searchMedicineBtn').addEventListener('click', searchMedicines);
    document.getElementById('medicineSearch').addEventListener('keyup', function (e) {
        if (e.key === 'Enter') searchMedicines();
    });

    // Filter functionality
    document.getElementById('medicineCategoryFilter').addEventListener('change', function () {
        loadMedicinesTable(this.value, document.getElementById('medicineAvailabilityFilter').value);
    });

    document.getElementById('medicineAvailabilityFilter').addEventListener('change', function () {
        loadMedicinesTable(document.getElementById('medicineCategoryFilter').value, this.value);
    });

    // View cart button
    document.getElementById('viewCartBtn').addEventListener('click', function () {
        updateCartDisplay();
        const cartModal = new bootstrap.Modal(document.getElementById('shoppingCartModal'));
        cartModal.show();
    });

    // Payment method change
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', function () {
            document.getElementById('bankPaymentForm').style.display =
                (this.value === 'cbe' || this.value === 'abyssinia') ? 'block' : 'none';
        });
    });

    // Checkout button
    document.getElementById('checkoutBtn').addEventListener('click', processPayment);
}

function loadMedicinesTable(categoryFilter = 'all', availabilityFilter = 'all') {
    const tableBody = document.querySelector('#medicinesTable tbody');
    tableBody.innerHTML = '';

    let filteredMedicines = medicines;

    // Apply category filter
    if (categoryFilter !== 'all') {
        filteredMedicines = filteredMedicines.filter(m => m.category === categoryFilter);
    }

    // Apply availability filter
    if (availabilityFilter === 'in-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 20);
    } else if (availabilityFilter === 'low-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 0 && m.quantity <= 20);
    } else if (availabilityFilter === 'out-of-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity === 0);
    }

    filteredMedicines.forEach(medicine => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${medicine.id}</td>
            <td>${medicine.name}</td>
            <td>${formatCategory(medicine.category)}</td>
            <td>${medicine.price.toFixed(2)}</td>
            <td>
                <span class="badge ${getStockBadgeClass(medicine.quantity)}">
                    ${medicine.quantity > 0 ? medicine.quantity : 'Out of Stock'}
                </span>
            </td>
            <td>${formatDate(medicine.expiry)}</td>
            <td>
                <button class="btn btn-sm btn-success add-to-cart" data-id="${medicine.id}" ${medicine.quantity === 0 ? 'disabled' : ''}>
                    <i class="fas fa-cart-plus"></i> Add
                </button>
                <button class="btn btn-sm btn-primary view-medicine" data-id="${medicine.id}">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Add event listeners to buttons
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            addToCart(medicineId);
        });
    });

    document.querySelectorAll('.view-medicine').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            viewMedicineDetails(medicineId);
        });
    });
}

function setupMedicineForm() {
    // Save new medicine
    document.getElementById('saveMedicineBtn').addEventListener('click', saveNewMedicine);
}

function saveNewMedicine() {
    const name = document.getElementById('medicineName').value;
    const category = document.getElementById('medicineCategory').value;
    const price = parseFloat(document.getElementById('medicinePrice').value);
    const quantity = parseInt(document.getElementById('medicineQuantity').value);
    const expiry = document.getElementById('medicineExpiry').value;
    const description = document.getElementById('medicineDescription').value;

    if (!name || !category || isNaN(price) || isNaN(quantity) || !expiry) {
        alert('Please fill in all required fields');
        return;
    }

    // Generate new ID
    const newId = medicines.length > 0 ? Math.max(...medicines.map(m => m.id)) + 1 : 1;

    // Create new medicine
    const newMedicine = {
        id: newId,
        name,
        category,
        price,
        quantity,
        expiry,
        description: description || null
    };

    medicines.push(newMedicine);

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('addMedicineModal')).hide();
    loadMedicinesTable();

    // Reset form
    document.getElementById('addMedicineForm').reset();
}

function viewMedicineDetails(medicineId) {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine) return;

    // You can implement a detailed view modal here
    alert(`Medicine Details:\n\nName: ${medicine.name}\nCategory: ${formatCategory(medicine.category)}\nPrice: ${medicine.price.toFixed(2)} ETB\nQuantity: ${medicine.quantity}\nExpiry: ${formatDate(medicine.expiry)}\nDescription: ${medicine.description || 'N/A'}`);
}

function searchMedicines() {
    const searchTerm = document.getElementById('medicineSearch').value.toLowerCase();
    const categoryFilter = document.getElementById('medicineCategoryFilter').value;
    const availabilityFilter = document.getElementById('medicineAvailabilityFilter').value;

    let filteredMedicines = medicines;

    // Apply search filter
    if (searchTerm) {
        filteredMedicines = filteredMedicines.filter(m =>
            m.name.toLowerCase().includes(searchTerm) ||
            (m.description && m.description.toLowerCase().includes(searchTerm)))
    }

    // Apply category filter
    if (categoryFilter !== 'all') {
        filteredMedicines = filteredMedicines.filter(m => m.category === categoryFilter);
    }

    // Apply availability filter
    if (availabilityFilter === 'in-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 20);
    } else if (availabilityFilter === 'low-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 0 && m.quantity <= 20);
    } else if (availabilityFilter === 'out-of-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity === 0);
    }

    const tableBody = document.querySelector('#medicinesTable tbody');
    tableBody.innerHTML = '';

    filteredMedicines.forEach(medicine => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${medicine.id}</td>
            <td>${medicine.name}</td>
            <td>${formatCategory(medicine.category)}</td>
            <td>${medicine.price.toFixed(2)}</td>
            <td>
                <span class="badge ${getStockBadgeClass(medicine.quantity)}">
                    ${medicine.quantity > 0 ? medicine.quantity : 'Out of Stock'}
                </span>
            </td>
            <td>${formatDate(medicine.expiry)}</td>
            <td>
                <button class="btn btn-sm btn-success add-to-cart" data-id="${medicine.id}" ${medicine.quantity === 0 ? 'disabled' : ''}>
                    <i class="fas fa-cart-plus"></i> Add
                </button>
                <button class="btn btn-sm btn-primary view-medicine" data-id="${medicine.id}">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Reattach event listeners
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            addToCart(medicineId);
        });
    });

    document.querySelectorAll('.view-medicine').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            viewMedicineDetails(medicineId);
        });
    });
}

// Cart Functions
function setupCart() {
    // Load cart from localStorage if available
    const savedCart = localStorage.getItem('pharmacyCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartCount();
    }
}

function addToCart(medicineId) {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine || medicine.quantity === 0) return;

    const existingItem = cart.find(item => item.id === medicineId);

    if (existingItem) {
        // Check if we have enough stock
        if (existingItem.quantity + 1 > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            return;
        }
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: medicine.id,
            name: medicine.name,
            price: medicine.price,
            quantity: 1
        });
    }

    updateCartCount();
    saveCartToStorage();

    // Show toast notification
    showToast(`${medicine.name} added to cart`, 'success');
}

function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = totalItems;
}

function updateCartDisplay() {
    const tableBody = document.querySelector('#cartTable tbody');
    tableBody.innerHTML = '';

    if (cart.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Your cart is empty</td></tr>';
        document.getElementById('cartSubtotal').textContent = '0.00 ETB';
        document.getElementById('cartTax').textContent = '0.00 ETB';
        document.getElementById('cartTotal').textContent = '0.00 ETB';
        return;
    }

    let subtotal = 0;

    cart.forEach(item => {
        const total = item.price * item.quantity;
        subtotal += total;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.price.toFixed(2)}</td>
            <td>
                <div class="input-group input-group-sm" style="width: 120px;">
                    <button class="btn btn-outline-secondary decrease-quantity" data-id="${item.id}" type="button">-</button>
                    <input type="number" class="form-control text-center" value="${item.quantity}" min="1" max="10" data-id="${item.id}">
                    <button class="btn btn-outline-secondary increase-quantity" data-id="${item.id}" type="button">+</button>
                </div>
            </td>
            <td>${total.toFixed(2)}</td>
            <td>
                <button class="btn btn-sm btn-danger remove-from-cart" data-id="${item.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    const tax = subtotal * 0.15; // 15% tax
    const total = subtotal + tax;

    document.getElementById('cartSubtotal').textContent = `${subtotal.toFixed(2)} ETB`;
    document.getElementById('cartTax').textContent = `${tax.toFixed(2)} ETB`;
    document.getElementById('cartTotal').textContent = `${total.toFixed(2)} ETB`;

    // Add event listeners to cart buttons
    document.querySelectorAll('.decrease-quantity').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            updateCartItemQuantity(itemId, -1);
        });
    });

    document.querySelectorAll('.increase-quantity').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            updateCartItemQuantity(itemId, 1);
        });
    });

    document.querySelectorAll('.remove-from-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            removeFromCart(itemId);
        });
    });

    document.querySelectorAll('#cartTable input[type="number"]').forEach(input => {
        input.addEventListener('change', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            const newQuantity = parseInt(this.value);
            updateCartItemQuantity(itemId, 0, newQuantity);
        });
    });
}

function updateCartItemQuantity(itemId, change, newQuantity = null) {
    const itemIndex = cart.findIndex(item => item.id === itemId);
    if (itemIndex === -1) return;

    const medicine = medicines.find(m => m.id === itemId);
    if (!medicine) return;

    if (newQuantity !== null) {
        // Direct quantity update
        if (newQuantity < 1) newQuantity = 1;
        if (newQuantity > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            newQuantity = medicine.quantity;
        }
        cart[itemIndex].quantity = newQuantity;
    } else {
        // Increment/decrement
        const newQty = cart[itemIndex].quantity + change;
        if (newQty < 1) return;
        if (newQty > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            return;
        }
        cart[itemIndex].quantity = newQty;
    }

    if (cart[itemIndex].quantity === 0) {
        cart.splice(itemIndex, 1);
    }

    updateCartCount();
    updateCartDisplay();
    saveCartToStorage();
}

function removeFromCart(itemId) {
    cart = cart.filter(item => item.id !== itemId);
    updateCartCount();
    updateCartDisplay();
    saveCartToStorage();
}

function saveCartToStorage() {
    localStorage.setItem('pharmacyCart', JSON.stringify(cart));
}

function processPayment() {
    const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;

    if (cart.length === 0) {
        alert('Your cart is empty');
        return;
    }

    if (paymentMethod === 'cbe' || paymentMethod === 'abyssinia') {
        const cardNumber = document.getElementById('cardNumber').value;
        const expiryDate = document.getElementById('expiryDate').value;
        const cvv = document.getElementById('cvv').value;
        const cardHolder = document.getElementById('cardHolder').value;

        if (!cardNumber || !expiryDate || !cvv || !cardHolder) {
            alert('Please fill in all payment details');
            return;
        }

        // Validate card number (simplified)
        if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
            alert('Please enter a valid 16-digit card number');
            return;
        }
    }

    // In a real app, you would send this to your payment processor
    // For this demo, we'll just show a success message

    // Generate receipt info
    const now = new Date();
    const transactionId = 'TRX-' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    const total = parseFloat(document.getElementById('cartTotal').textContent);

    document.getElementById('receiptTransactionId').textContent = transactionId;
    document.getElementById('receiptDate').textContent = now.toLocaleString('en-US', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
    document.getElementById('receiptMethod').textContent =
        paymentMethod === 'cash' ? 'Cash' :
            paymentMethod === 'cbe' ? 'CBE Birr' : 'Abyssinia Bank';
    document.getElementById('receiptAmount').textContent = total.toFixed(2) + ' ETB';

    // Update stock quantities
    cart.forEach(cartItem => {
        const medicine = medicines.find(m => m.id === cartItem.id);
        if (medicine) {
            medicine.quantity -= cartItem.quantity;
        }
    });

    // Clear cart
    cart = [];
    updateCartCount();
    saveCartToStorage();

    // Close cart modal and show success
    bootstrap.Modal.getInstance(document.getElementById('shoppingCartModal')).hide();

    // Show success modal after a short delay
    setTimeout(() => {
        const successModal = new bootstrap.Modal(document.getElementById('paymentSuccessModal'));
        successModal.show();
    }, 500);

    // Reload medicines table to reflect stock changes
    loadMedicinesTable();
}

// Utility Functions
function formatCategory(category) {
    const categories = {
        'antibiotics': 'Antibiotics',
        'antimalarial': 'Antimalarial',
        'painkillers': 'Painkillers',
        'diabetes': 'Diabetes',
        'hypertension': 'Hypertension',
        'other': 'Other'
    };
    return categories[category] || category;
}

function getStockBadgeClass(quantity) {
    if (quantity === 0) return 'bg-danger';
    if (quantity <= 20) return 'bg-warning text-dark';
    return 'bg-success';
}

function showToast(message, type = 'info') {
    // You can implement a proper toast notification here
    alert(`${type.toUpperCase()}: ${message}`);
}

// Update DOM Ready Function to include pharmacy initialization
document.addEventListener('DOMContentLoaded', function () {
    const path = window.location.pathname;
    const page = path.split("/").pop();

    if (page === "pharmacy.html") {
        initializePharmacyPage();
    }
    // ... rest of your existing code
});