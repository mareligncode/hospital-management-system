// Hospital Management System - Frontend Functionality

// Sample Data (in a real app, this would come from a backend API)
let patients = [
    { id: 1, firstName: "John", lastName: "Doe", gender: "Male", dob: "1985-05-15", phone: "555-123-4567", email: "john.doe@example.com", address: "123 Main St, Anytown", status: "Active", medicalHistory: "Hypertension" },
    { id: 2, firstName: "Jane", lastName: "Smith", gender: "Female", dob: "1990-08-22", phone: "555-987-6543", email: "jane.smith@example.com", address: "456 Oak Ave, Somewhere", status: "Active", medicalHistory: "None" },
    { id: 3, firstName: "Robert", lastName: "Johnson", gender: "Male", dob: "1978-03-10", phone: "555-456-7890", email: "robert.j@example.com", address: "789 Pine Rd, Nowhere", status: "Inactive", medicalHistory: "Diabetes, Asthma" }
];

let staff = [
    { id: 1, firstName: "Sarah", lastName: "Williams", role: "Doctor", department: "Cardiology", email: "sarah.w@hospital.com", phone: "555-111-2222", dob: "1980-07-15", hireDate: "2015-06-01", status: "Active", qualifications: "MD, Cardiology Specialist" },
    { id: 2, firstName: "Michael", lastName: "Brown", role: "Nurse", department: "Emergency", email: "michael.b@hospital.com", phone: "555-333-4444", dob: "1985-11-20", hireDate: "2018-03-15", status: "Active", qualifications: "RN, Emergency Care" },
    { id: 3, firstName: "Emily", lastName: "Davis", role: "Administrator", department: "Administration", email: "emily.d@hospital.com", phone: "555-555-6666", dob: "1975-04-05", hireDate: "2010-01-10", status: "Active", qualifications: "MBA, Healthcare Management" }
];

let appointments = [
    { id: 1, patientId: 1, doctorId: 1, date: "2023-06-15", time: "09:00", reason: "Follow-up for hypertension", status: "Scheduled" },
    { id: 2, patientId: 2, doctorId: 1, date: "2023-06-15", time: "10:30", reason: "Annual checkup", status: "Scheduled" },
    { id: 3, patientId: 3, doctorId: 2, date: "2023-06-16", time: "14:00", reason: "Diabetes management", status: "Confirmed" }
];

// DOM Ready Function
document.addEventListener('DOMContentLoaded', function () {
    // Initialize the page based on which HTML file is loaded
    const path = window.location.pathname;
    const page = path.split("/").pop();

    // Update dashboard stats
    if (page === "index.html" || page === "") {
        updateDashboardStats();
        loadRecentAppointments();
    }

    // Initialize patients page
    if (page === "patients.html") {
        loadPatientsTable();
        setupPatientForm();
    }

    // Initialize appointments page
    if (page === "appointments.html") {
        loadAppointmentsTable();
        setupAppointmentForm();
        initializeCalendar();
    }

    // Initialize staff page
    if (page === "staff.html") {
        loadStaffTable();
        setupStaffForm();
    }
});

// Dashboard Functions
function updateDashboardStats() {
    document.getElementById('totalPatients').textContent = patients.length;
    document.getElementById('todaysAppointments').textContent = getTodaysAppointments().length;
    document.getElementById('activeStaff').textContent = staff.filter(s => s.status === "Active").length;
    document.getElementById('availableRooms').textContent = 15; // Hardcoded for demo
}

function getTodaysAppointments() {
    const today = new Date().toISOString().split('T')[0];
    return appointments.filter(a => a.date === today);
}

function loadRecentAppointments() {
    const tableBody = document.querySelector('#recentAppointments tbody');
    tableBody.innerHTML = '';

    // Sort appointments by date (newest first)
    const sortedAppointments = [...appointments].sort((a, b) => new Date(b.date) - new Date(a.date));

    // Get the 5 most recent
    const recent = sortedAppointments.slice(0, 5);

    recent.forEach(appointment => {
        const patient = patients.find(p => p.id === appointment.patientId);
        const doctor = staff.find(d => d.id === appointment.doctorId);

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${appointment.id}</td>
            <td>${patient ? `${patient.firstName} ${patient.lastName}` : 'Unknown'}</td>
            <td>${doctor ? `Dr. ${doctor.lastName}` : 'Unknown'}</td>
            <td>${formatDate(appointment.date)}</td>
            <td>${formatTime(appointment.time)}</td>
            <td><span class="badge ${getStatusBadgeClass(appointment.status)}">${appointment.status}</span></td>
        `;
        tableBody.appendChild(row);
    });
}

// Patients Page Functions
function loadPatientsTable(filter = 'all') {
    const tableBody = document.querySelector('#patientsTable tbody');
    tableBody.innerHTML = '';

    let filteredPatients = patients;

    if (filter === 'active') {
        filteredPatients = patients.filter(p => p.status === 'Active');
    } else if (filter === 'inactive') {
        filteredPatients = patients.filter(p => p.status === 'Inactive');
    } else if (filter === 'admitted') {
        filteredPatients = patients.filter(p => p.status === 'Admitted');
    }

    filteredPatients.forEach(patient => {
        const age = calculateAge(patient.dob);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${patient.id}</td>
            <td>${patient.firstName} ${patient.lastName}</td>
            <td>${patient.gender}</td>
            <td>${age}</td>
            <td>${patient.phone}</td>
            <td><span class="badge ${getStatusBadgeClass(patient.status)}">${patient.status}</span></td>
            <td>
                <button class="btn btn-sm btn-primary view-patient" data-id="${patient.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning edit-patient" data-id="${patient.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-patient" data-id="${patient.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Add event listeners to buttons
    document.querySelectorAll('.view-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            viewPatientDetails(patientId);
        });
    });

    document.querySelectorAll('.edit-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            editPatient(patientId);
        });
    });

    document.querySelectorAll('.delete-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            deletePatient(patientId);
        });
    });
}

function setupPatientForm() {
    // Search functionality
    document.getElementById('searchPatientBtn').addEventListener('click', searchPatients);
    document.getElementById('patientSearch').addEventListener('keyup', function (e) {
        if (e.key === 'Enter') searchPatients();
    });

    // Filter functionality
    document.getElementById('patientFilter').addEventListener('change', function () {
        loadPatientsTable(this.value);
    });

    // Save new patient
    document.getElementById('savePatientBtn').addEventListener('click', saveNewPatient);

    // Update existing patient
    document.getElementById('updatePatientBtn').addEventListener('click', updatePatient);
}

function viewPatientDetails(patientId) {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    const age = calculateAge(patient.dob);
    const modalContent = document.getElementById('patientDetailsContent');

    modalContent.innerHTML = `
        <div class="row mb-3">
            <div class="col-md-6">
                <h5>Personal Information</h5>
                <p><strong>Name:</strong> ${patient.firstName} ${patient.lastName}</p>
                <p><strong>Gender:</strong> ${patient.gender}</p>
                <p><strong>Date of Birth:</strong> ${formatDate(patient.dob)} (${age} years)</p>
                <p><strong>Status:</strong> <span class="badge ${getStatusBadgeClass(patient.status)}">${patient.status}</span></p>
            </div>
            <div class="col-md-6">
                <h5>Contact Information</h5>
                <p><strong>Phone:</strong> ${patient.phone}</p>
                <p><strong>Email:</strong> ${patient.email || 'N/A'}</p>
                <p><strong>Address:</strong> ${patient.address || 'N/A'}</p>
            </div>
        </div>
        <div class="mb-3">
            <h5>Medical History</h5>
            <p>${patient.medicalHistory || 'No significant medical history recorded.'}</p>
        </div>
        <form id="editPatientForm" style="display: none;">
            <input type="hidden" id="editPatientId" value="${patient.id}">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editFirstName" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="editFirstName" value="${patient.firstName}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editLastName" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="editLastName" value="${patient.lastName}" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editGender" class="form-label">Gender</label>
                    <select class="form-select" id="editGender" required>
                        <option value="Male" ${patient.gender === 'Male' ? 'selected' : ''}>Male</option>
                        <option value="Female" ${patient.gender === 'Female' ? 'selected' : ''}>Female</option>
                        <option value="Other" ${patient.gender === 'Other' ? 'selected' : ''}>Other</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editDob" class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="editDob" value="${patient.dob}" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editPhone" class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" id="editPhone" value="${patient.phone}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editEmail" class="form-label">Email</label>
                    <input type="email" class="form-control" id="editEmail" value="${patient.email || ''}">
                </div>
            </div>
            <div class="mb-3">
                <label for="editAddress" class="form-label">Address</label>
                <textarea class="form-control" id="editAddress" rows="2">${patient.address || ''}</textarea>
            </div>
            <div class="mb-3">
                <label for="editStatus" class="form-label">Status</label>
                <select class="form-select" id="editStatus" required>
                    <option value="Active" ${patient.status === 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${patient.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="Admitted" ${patient.status === 'Admitted' ? 'selected' : ''}>Admitted</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="editMedicalHistory" class="form-label">Medical History</label>
                <textarea class="form-control" id="editMedicalHistory" rows="3">${patient.medicalHistory || ''}</textarea>
            </div>
        </form>
    `;

    const modal = new bootstrap.Modal(document.getElementById('patientDetailsModal'));
    modal.show();
}

function editPatient(patientId) {
    viewPatientDetails(patientId);
    document.getElementById('editPatientForm').style.display = 'block';
    document.querySelector('#patientDetailsContent > div:first-child').style.display = 'none';
    document.querySelector('#patientDetailsContent > div:nth-child(2)').style.display = 'none';
}

function saveNewPatient() {
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const gender = document.getElementById('gender').value;
    const dob = document.getElementById('dob').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const medicalHistory = document.getElementById('medicalHistory').value;

    if (!firstName || !lastName || !gender || !dob || !phone) {
        alert('Please fill in all required fields');
        return;
    }

    // Generate new ID
    const newId = patients.length > 0 ? Math.max(...patients.map(p => p.id)) + 1 : 1;

    // Create new patient
    const newPatient = {
        id: newId,
        firstName,
        lastName,
        gender,
        dob,
        phone,
        email: email || null,
        address: address || null,
        status: 'Active',
        medicalHistory: medicalHistory || null
    };

    patients.push(newPatient);

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('addPatientModal')).hide();
    loadPatientsTable();

    // Reset form
    document.getElementById('addPatientForm').reset();
}

function updatePatient() {
    const patientId = parseInt(document.getElementById('editPatientId').value);
    const patientIndex = patients.findIndex(p => p.id === patientId);

    if (patientIndex === -1) return;

    patients[patientIndex] = {
        ...patients[patientIndex],
        firstName: document.getElementById('editFirstName').value,
        lastName: document.getElementById('editLastName').value,
        gender: document.getElementById('editGender').value,
        dob: document.getElementById('editDob').value,
        phone: document.getElementById('editPhone').value,
        email: document.getElementById('editEmail').value || null,
        address: document.getElementById('editAddress').value || null,
        status: document.getElementById('editStatus').value,
        medicalHistory: document.getElementById('editMedicalHistory').value || null
    };

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('patientDetailsModal')).hide();
    loadPatientsTable();
}

function deletePatient(patientId) {
    if (confirm('Are you sure you want to delete this patient record?')) {
        patients = patients.filter(p => p.id !== patientId);
        loadPatientsTable();
    }
}

function searchPatients() {
    const searchTerm = document.getElementById('patientSearch').value.toLowerCase();
    const filteredPatients = patients.filter(p =>
        p.firstName.toLowerCase().includes(searchTerm) ||
        p.lastName.toLowerCase().includes(searchTerm) ||
        p.phone.includes(searchTerm) ||
        (p.email && p.email.toLowerCase().includes(searchTerm))
    );

    const tableBody = document.querySelector('#patientsTable tbody');
    tableBody.innerHTML = '';

    filteredPatients.forEach(patient => {
        const age = calculateAge(patient.dob);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${patient.id}</td>
            <td>${patient.firstName} ${patient.lastName}</td>
            <td>${patient.gender}</td>
            <td>${age}</td>
            <td>${patient.phone}</td>
            <td><span class="badge ${getStatusBadgeClass(patient.status)}">${patient.status}</span></td>
            <td>
                <button class="btn btn-sm btn-primary view-patient" data-id="${patient.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning edit-patient" data-id="${patient.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-patient" data-id="${patient.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Reattach event listeners
    document.querySelectorAll('.view-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            viewPatientDetails(patientId);
        });
    });

    document.querySelectorAll('.edit-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            editPatient(patientId);
        });
    });

    document.querySelectorAll('.delete-patient').forEach(btn => {
        btn.addEventListener('click', function () {
            const patientId = parseInt(this.getAttribute('data-id'));
            deletePatient(patientId);
        });
    });
}

// Appointments Page Functions
function loadAppointmentsTable(filter = 'all') {
    const tableBody = document.querySelector('#appointmentsTable tbody');
    tableBody.innerHTML = '';

    // Sort appointments by date (soonest first)
    const sortedAppointments = [...appointments].sort((a, b) => {
        const dateA = new Date(`${a.date}T${a.time}`);
        const dateB = new Date(`${b.date}T${b.time}`);
        return dateA - dateB;
    });

    sortedAppointments.forEach(appointment => {
        const patient = patients.find(p => p.id === appointment.patientId);
        const doctor = staff.find(d => d.id === appointment.doctorId && d.role === 'Doctor');

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${appointment.id}</td>
            <td>${patient ? `${patient.firstName} ${patient.lastName}` : 'Unknown'}</td>
            <td>${doctor ? `Dr. ${doctor.lastName}` : 'Unknown'}</td>
            <td>${formatDate(appointment.date)}</td>
            <td>${formatTime(appointment.time)}</td>
            <td><span class="badge ${getStatusBadgeClass(appointment.status)}">${appointment.status}</span></td>
            <td>
                <button class="btn btn-sm btn-primary view-appointment" data-id="${appointment.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning edit-appointment" data-id="${appointment.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-appointment" data-id="${appointment.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Add event listeners to buttons
    document.querySelectorAll('.view-appointment').forEach(btn => {
        btn.addEventListener('click', function () {
            const appointmentId = parseInt(this.getAttribute('data-id'));
            viewAppointmentDetails(appointmentId);
        });
    });

    document.querySelectorAll('.edit-appointment').forEach(btn => {
        btn.addEventListener('click', function () {
            const appointmentId = parseInt(this.getAttribute('data-id'));
            editAppointment(appointmentId);
        });
    });

    document.querySelectorAll('.delete-appointment').forEach(btn => {
        btn.addEventListener('click', function () {
            const appointmentId = parseInt(this.getAttribute('data-id'));
            deleteAppointment(appointmentId);
        });
    });
}

function setupAppointmentForm() {
    // Populate patient and doctor dropdowns
    const patientSelect = document.getElementById('appointmentPatient');
    const doctorSelect = document.getElementById('appointmentDoctor');

    patientSelect.innerHTML = '<option value="">Select Patient</option>';
    doctorSelect.innerHTML = '<option value="">Select Doctor</option>';

    patients.forEach(patient => {
        const option = document.createElement('option');
        option.value = patient.id;
        option.textContent = `${patient.firstName} ${patient.lastName}`;
        patientSelect.appendChild(option);
    });

    staff.filter(s => s.role === 'Doctor').forEach(doctor => {
        const option = document.createElement('option');
        option.value = doctor.id;
        option.textContent = `Dr. ${doctor.lastName}`;
        doctorSelect.appendChild(option);
    });

    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('appointmentDate').value = today;

    // Save new appointment
    document.getElementById('saveAppointmentBtn').addEventListener('click', saveNewAppointment);

    // Update existing appointment
    document.getElementById('updateAppointmentBtn').addEventListener('click', updateAppointment);

    // Calendar navigation
    document.getElementById('prevWeekBtn').addEventListener('click', showPreviousWeek);
    document.getElementById('nextWeekBtn').addEventListener('click', showNextWeek);
}

function initializeCalendar() {
    const today = new Date();
    currentWeekStart = new Date(today.setDate(today.getDate() - today.getDay() + 1)); // Start on Monday
    updateCalendar();
}

function updateCalendar() {
    const calendarBody = document.querySelector('#appointmentCalendar tbody');
    calendarBody.innerHTML = '';

    // Update week range display
    const weekEnd = new Date(currentWeekStart);
    weekEnd.setDate(weekEnd.getDate() + 5); // Show Monday to Saturday

    document.getElementById('currentWeekRange').textContent =
        `Week of ${formatDate(currentWeekStart.toISOString().split('T')[0])} to ${formatDate(weekEnd.toISOString().split('T')[0])}`;

    // Create time slots (9am to 5pm)
    for (let hour = 9; hour <= 17; hour++) {
        const row = document.createElement('tr');
        const timeCell = document.createElement('td');
        timeCell.className = 'calendar-time';
        timeCell.textContent = `${hour}:00 - ${hour + 1}:00`;
        row.appendChild(timeCell);

        // Create cells for each day (Monday to Saturday)
        for (let day = 0; day < 6; day++) {
            const cellDate = new Date(currentWeekStart);
            cellDate.setDate(cellDate.getDate() + day);
            const dateStr = cellDate.toISOString().split('T')[0];

            const cell = document.createElement('td');

            // Find appointments for this time slot and day
            const hourStart = `${hour.toString().padStart(2, '0')}:00`;
            const hourEnd = `${(hour + 1).toString().padStart(2, '0')}:00`;

            const slotAppointments = appointments.filter(a =>
                a.date === dateStr &&
                a.time >= hourStart &&
                a.time < hourEnd
            );

            slotAppointments.forEach(appointment => {
                const patient = patients.find(p => p.id === appointment.patientId);
                const doctor = staff.find(d => d.id === appointment.doctorId);

                const apptDiv = document.createElement('div');
                apptDiv.className = 'calendar-appointment';
                apptDiv.innerHTML = `
                    <strong>${patient ? patient.firstName : 'Unknown'}</strong><br>
                    ${doctor ? `Dr. ${doctor.lastName}` : 'Unknown'}
                `;
                apptDiv.addEventListener('click', () => viewAppointmentDetails(appointment.id));
                cell.appendChild(apptDiv);
            });

            row.appendChild(cell);
        }

        calendarBody.appendChild(row);
    }
}

function showPreviousWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() - 7);
    updateCalendar();
}

function showNextWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    updateCalendar();
}

function viewAppointmentDetails(appointmentId) {
    const appointment = appointments.find(a => a.id === appointmentId);
    if (!appointment) return;

    const patient = patients.find(p => p.id === appointment.patientId);
    const doctor = staff.find(d => d.id === appointment.doctorId);

    const modalContent = document.getElementById('appointmentDetailsContent');

    modalContent.innerHTML = `
        <div class="mb-3">
            <h5>Appointment Information</h5>
            <p><strong>Patient:</strong> ${patient ? `${patient.firstName} ${patient.lastName}` : 'Unknown'}</p>
            <p><strong>Doctor:</strong> ${doctor ? `Dr. ${doctor.lastName}` : 'Unknown'}</p>
            <p><strong>Date:</strong> ${formatDate(appointment.date)}</p>
            <p><strong>Time:</strong> ${formatTime(appointment.time)}</p>
            <p><strong>Status:</strong> <span class="badge ${getStatusBadgeClass(appointment.status)}">${appointment.status}</span></p>
            <p><strong>Reason:</strong> ${appointment.reason || 'Not specified'}</p>
        </div>
        <form id="editAppointmentForm" style="display: none;">
            <input type="hidden" id="editAppointmentId" value="${appointment.id}">
            <div class="mb-3">
                <label for="editAppointmentPatient" class="form-label">Patient</label>
                <select class="form-select" id="editAppointmentPatient" required>
                    ${patients.map(p =>
        `<option value="${p.id}" ${p.id === appointment.patientId ? 'selected' : ''}>
                            ${p.firstName} ${p.lastName}
                        </option>`
    ).join('')}
                </select>
            </div>
            <div class="mb-3">
                <label for="editAppointmentDoctor" class="form-label">Doctor</label>
                <select class="form-select" id="editAppointmentDoctor" required>
                    ${staff.filter(s => s.role === 'Doctor').map(d =>
        `<option value="${d.id}" ${d.id === appointment.doctorId ? 'selected' : ''}>
                            Dr. ${d.lastName}
                        </option>`
    ).join('')}
                </select>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editAppointmentDate" class="form-label">Date</label>
                    <input type="date" class="form-control" id="editAppointmentDate" value="${appointment.date}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editAppointmentTime" class="form-label">Time</label>
                    <input type="time" class="form-control" id="editAppointmentTime" value="${appointment.time}" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="editAppointmentStatus" class="form-label">Status</label>
                <select class="form-select" id="editAppointmentStatus" required>
                    <option value="Scheduled" ${appointment.status === 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                    <option value="Confirmed" ${appointment.status === 'Confirmed' ? 'selected' : ''}>Confirmed</option>
                    <option value="Completed" ${appointment.status === 'Completed' ? 'selected' : ''}>Completed</option>
                    <option value="Cancelled" ${appointment.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="editAppointmentReason" class="form-label">Reason</label>
                <textarea class="form-control" id="editAppointmentReason" rows="3">${appointment.reason || ''}</textarea>
            </div>
        </form>
    `;

    const modal = new bootstrap.Modal(document.getElementById('appointmentDetailsModal'));
    modal.show();
}

function editAppointment(appointmentId) {
    viewAppointmentDetails(appointmentId);
    document.getElementById('editAppointmentForm').style.display = 'block';
    document.querySelector('#appointmentDetailsContent > div:first-child').style.display = 'none';
}

function saveNewAppointment() {
    const patientId = parseInt(document.getElementById('appointmentPatient').value);
    const doctorId = parseInt(document.getElementById('appointmentDoctor').value);
    const date = document.getElementById('appointmentDate').value;
    const time = document.getElementById('appointmentTime').value;
    const reason = document.getElementById('appointmentReason').value;

    if (!patientId || !doctorId || !date || !time) {
        alert('Please fill in all required fields');
        return;
    }

    // Generate new ID
    const newId = appointments.length > 0 ? Math.max(...appointments.map(a => a.id)) + 1 : 1;

    // Create new appointment
    const newAppointment = {
        id: newId,
        patientId,
        doctorId,
        date,
        time,
        reason: reason || null,
        status: 'Scheduled'
    };

    appointments.push(newAppointment);

    // Close modal and refresh table/calendar
    bootstrap.Modal.getInstance(document.getElementById('addAppointmentModal')).hide();
    loadAppointmentsTable();
    updateCalendar();

    // Reset form
    document.getElementById('addAppointmentForm').reset();
}

function updateAppointment() {
    const appointmentId = parseInt(document.getElementById('editAppointmentId').value);
    const appointmentIndex = appointments.findIndex(a => a.id === appointmentId);

    if (appointmentIndex === -1) return;

    appointments[appointmentIndex] = {
        ...appointments[appointmentIndex],
        patientId: parseInt(document.getElementById('editAppointmentPatient').value),
        doctorId: parseInt(document.getElementById('editAppointmentDoctor').value),
        date: document.getElementById('editAppointmentDate').value,
        time: document.getElementById('editAppointmentTime').value,
        status: document.getElementById('editAppointmentStatus').value,
        reason: document.getElementById('editAppointmentReason').value || null
    };

    // Close modal and refresh table/calendar
    bootstrap.Modal.getInstance(document.getElementById('appointmentDetailsModal')).hide();
    loadAppointmentsTable();
    updateCalendar();
}

function deleteAppointment(appointmentId) {
    if (confirm('Are you sure you want to delete this appointment?')) {
        appointments = appointments.filter(a => a.id !== appointmentId);
        loadAppointmentsTable();
        updateCalendar();
    }
}

// Staff Page Functions
function loadStaffTable(filter = 'all') {
    const tableBody = document.querySelector('#staffTable tbody');
    tableBody.innerHTML = '';

    let filteredStaff = staff;

    if (filter === 'doctor') {
        filteredStaff = staff.filter(s => s.role === 'Doctor');
    } else if (filter === 'nurse') {
        filteredStaff = staff.filter(s => s.role === 'Nurse');
    } else if (filter === 'admin') {
        filteredStaff = staff.filter(s => s.role === 'Administrator');
    } else if (filter === 'other') {
        filteredStaff = staff.filter(s => s.role !== 'Doctor' && s.role !== 'Nurse' && s.role !== 'Administrator');
    }

    filteredStaff.forEach(staffMember => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${staffMember.id}</td>
            <td>${staffMember.firstName} ${staffMember.lastName}</td>
            <td>${staffMember.role}</td>
            <td>${staffMember.department}</td>
            <td>${staffMember.phone}</td>
            <td><span class="badge ${getStatusBadgeClass(staffMember.status)}">${staffMember.status}</span></td>
            <td>
                <button class="btn btn-sm btn-primary view-staff" data-id="${staffMember.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning edit-staff" data-id="${staffMember.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-staff" data-id="${staffMember.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Add event listeners to buttons
    document.querySelectorAll('.view-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            viewStaffDetails(staffId);
        });
    });

    document.querySelectorAll('.edit-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            editStaff(staffId);
        });
    });

    document.querySelectorAll('.delete-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            deleteStaff(staffId);
        });
    });
}

function setupStaffForm() {
    // Search functionality
    document.getElementById('searchStaffBtn').addEventListener('click', searchStaff);
    document.getElementById('staffSearch').addEventListener('keyup', function (e) {
        if (e.key === 'Enter') searchStaff();
    });

    // Filter functionality
    document.getElementById('staffFilter').addEventListener('change', function () {
        loadStaffTable(this.value);
    });

    // Save new staff
    document.getElementById('saveStaffBtn').addEventListener('click', saveNewStaff);

    // Update existing staff
    document.getElementById('updateStaffBtn').addEventListener('click', updateStaff);
}

function viewStaffDetails(staffId) {
    const staffMember = staff.find(s => s.id === staffId);
    if (!staffMember) return;

    const age = calculateAge(staffMember.dob);
    const yearsWorked = calculateYearsWorked(staffMember.hireDate);
    const modalContent = document.getElementById('staffDetailsContent');

    modalContent.innerHTML = `
        <div class="row mb-3">
            <div class="col-md-6">
                <h5>Personal Information</h5>
                <p><strong>Name:</strong> ${staffMember.firstName} ${staffMember.lastName}</p>
                <p><strong>Role:</strong> ${staffMember.role}</p>
                <p><strong>Department:</strong> ${staffMember.department}</p>
                <p><strong>Date of Birth:</strong> ${formatDate(staffMember.dob)} (${age} years)</p>
                <p><strong>Status:</strong> <span class="badge ${getStatusBadgeClass(staffMember.status)}">${staffMember.status}</span></p>
            </div>
            <div class="col-md-6">
                <h5>Employment Information</h5>
                <p><strong>Hire Date:</strong> ${formatDate(staffMember.hireDate)} (${yearsWorked} years)</p>
                <p><strong>Email:</strong> ${staffMember.email}</p>
                <p><strong>Phone:</strong> ${staffMember.phone}</p>
                <p><strong>Address:</strong> ${staffMember.address || 'N/A'}</p>
            </div>
        </div>
        <div class="mb-3">
            <h5>Qualifications</h5>
            <p>${staffMember.qualifications || 'No qualifications recorded.'}</p>
        </div>
        <form id="editStaffForm" style="display: none;">
            <input type="hidden" id="editStaffId" value="${staffMember.id}">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editStaffFirstName" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="editStaffFirstName" value="${staffMember.firstName}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editStaffLastName" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="editStaffLastName" value="${staffMember.lastName}" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editStaffRole" class="form-label">Role</label>
                    <select class="form-select" id="editStaffRole" required>
                        <option value="Doctor" ${staffMember.role === 'Doctor' ? 'selected' : ''}>Doctor</option>
                        <option value="Nurse" ${staffMember.role === 'Nurse' ? 'selected' : ''}>Nurse</option>
                        <option value="Administrator" ${staffMember.role === 'Administrator' ? 'selected' : ''}>Administrator</option>
                        <option value="Technician" ${staffMember.role === 'Technician' ? 'selected' : ''}>Technician</option>
                        <option value="Other" ${staffMember.role === 'Other' ? 'selected' : ''}>Other</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editStaffDepartment" class="form-label">Department</label>
                    <select class="form-select" id="editStaffDepartment" required>
                        <option value="Cardiology" ${staffMember.department === 'Cardiology' ? 'selected' : ''}>Cardiology</option>
                        <option value="Neurology" ${staffMember.department === 'Neurology' ? 'selected' : ''}>Neurology</option>
                        <option value="Pediatrics" ${staffMember.department === 'Pediatrics' ? 'selected' : ''}>Pediatrics</option>
                        <option value="Orthopedics" ${staffMember.department === 'Orthopedics' ? 'selected' : ''}>Orthopedics</option>
                        <option value="Emergency" ${staffMember.department === 'Emergency' ? 'selected' : ''}>Emergency</option>
                        <option value="Administration" ${staffMember.department === 'Administration' ? 'selected' : ''}>Administration</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editStaffEmail" class="form-label">Email</label>
                    <input type="email" class="form-control" id="editStaffEmail" value="${staffMember.email}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editStaffPhone" class="form-label">Phone</label>
                    <input type="tel" class="form-control" id="editStaffPhone" value="${staffMember.phone}" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="editStaffDob" class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="editStaffDob" value="${staffMember.dob}" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="editStaffHireDate" class="form-label">Hire Date</label>
                    <input type="date" class="form-control" id="editStaffHireDate" value="${staffMember.hireDate}" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="editStaffAddress" class="form-label">Address</label>
                <textarea class="form-control" id="editStaffAddress" rows="2">${staffMember.address || ''}</textarea>
            </div>
            <div class="mb-3">
                <label for="editStaffStatus" class="form-label">Status</label>
                <select class="form-select" id="editStaffStatus" required>
                    <option value="Active" ${staffMember.status === 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${staffMember.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="On Leave" ${staffMember.status === 'On Leave' ? 'selected' : ''}>On Leave</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="editStaffQualifications" class="form-label">Qualifications</label>
                <textarea class="form-control" id="editStaffQualifications" rows="3">${staffMember.qualifications || ''}</textarea>
            </div>
        </form>
    `;

    const modal = new bootstrap.Modal(document.getElementById('staffDetailsModal'));
    modal.show();
}

function editStaff(staffId) {
    viewStaffDetails(staffId);
    document.getElementById('editStaffForm').style.display = 'block';
    document.querySelector('#staffDetailsContent > div:first-child').style.display = 'none';
    document.querySelector('#staffDetailsContent > div:nth-child(2)').style.display = 'none';
}

function saveNewStaff() {
    const firstName = document.getElementById('staffFirstName').value;
    const lastName = document.getElementById('staffLastName').value;
    const role = document.getElementById('staffRole').value;
    const department = document.getElementById('staffDepartment').value;
    const email = document.getElementById('staffEmail').value;
    const phone = document.getElementById('staffPhone').value;
    const dob = document.getElementById('staffDob').value;
    const hireDate = document.getElementById('staffHireDate').value;
    const address = document.getElementById('staffAddress').value;
    const qualifications = document.getElementById('staffQualifications').value;

    if (!firstName || !lastName || !role || !department || !email || !phone || !dob || !hireDate) {
        alert('Please fill in all required fields');
        return;
    }

    // Generate new ID
    const newId = staff.length > 0 ? Math.max(...staff.map(s => s.id)) + 1 : 1;

    // Create new staff member
    const newStaff = {
        id: newId,
        firstName,
        lastName,
        role,
        department,
        email,
        phone,
        dob,
        hireDate,
        address: address || null,
        qualifications: qualifications || null,
        status: 'Active'
    };

    staff.push(newStaff);

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('addStaffModal')).hide();
    loadStaffTable();

    // Reset form
    document.getElementById('addStaffForm').reset();
}

function updateStaff() {
    const staffId = parseInt(document.getElementById('editStaffId').value);
    const staffIndex = staff.findIndex(s => s.id === staffId);

    if (staffIndex === -1) return;

    staff[staffIndex] = {
        ...staff[staffIndex],
        firstName: document.getElementById('editStaffFirstName').value,
        lastName: document.getElementById('editStaffLastName').value,
        role: document.getElementById('editStaffRole').value,
        department: document.getElementById('editStaffDepartment').value,
        email: document.getElementById('editStaffEmail').value,
        phone: document.getElementById('editStaffPhone').value,
        dob: document.getElementById('editStaffDob').value,
        hireDate: document.getElementById('editStaffHireDate').value,
        address: document.getElementById('editStaffAddress').value || null,
        status: document.getElementById('editStaffStatus').value,
        qualifications: document.getElementById('editStaffQualifications').value || null
    };

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('staffDetailsModal')).hide();
    loadStaffTable();
}

function deleteStaff(staffId) {
    if (confirm('Are you sure you want to delete this staff record?')) {
        staff = staff.filter(s => s.id !== staffId);
        loadStaffTable();
    }
}

function searchStaff() {
    const searchTerm = document.getElementById('staffSearch').value.toLowerCase();
    const filteredStaff = staff.filter(s =>
        s.firstName.toLowerCase().includes(searchTerm) ||
        s.lastName.toLowerCase().includes(searchTerm) ||
        s.phone.includes(searchTerm) ||
        s.email.toLowerCase().includes(searchTerm) ||
        s.role.toLowerCase().includes(searchTerm) ||
        s.department.toLowerCase().includes(searchTerm)
    );

    const tableBody = document.querySelector('#staffTable tbody');
    tableBody.innerHTML = '';

    filteredStaff.forEach(staffMember => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${staffMember.id}</td>
            <td>${staffMember.firstName} ${staffMember.lastName}</td>
            <td>${staffMember.role}</td>
            <td>${staffMember.department}</td>
            <td>${staffMember.phone}</td>
            <td><span class="badge ${getStatusBadgeClass(staffMember.status)}">${staffMember.status}</span></td>
            <td>
                <button class="btn btn-sm btn-primary view-staff" data-id="${staffMember.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning edit-staff" data-id="${staffMember.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-staff" data-id="${staffMember.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Reattach event listeners
    document.querySelectorAll('.view-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            viewStaffDetails(staffId);
        });
    });

    document.querySelectorAll('.edit-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            editStaff(staffId);
        });
    });

    document.querySelectorAll('.delete-staff').forEach(btn => {
        btn.addEventListener('click', function () {
            const staffId = parseInt(this.getAttribute('data-id'));
            deleteStaff(staffId);
        });
    });
}

// Utility Functions
function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatTime(timeStr) {
    if (!timeStr) return 'N/A';
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
}

function calculateAge(dobStr) {
    const dob = new Date(dobStr);
    const diff = Date.now() - dob.getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

function calculateYearsWorked(hireDateStr) {
    const hireDate = new Date(hireDateStr);
    const diff = Date.now() - hireDate.getTime();
    const yearsDate = new Date(diff);
    return Math.abs(yearsDate.getUTCFullYear() - 1970);
}

function getStatusBadgeClass(status) {
    switch (status.toLowerCase()) {
        case 'active':
        case 'scheduled':
        case 'confirmed':
            return 'bg-success';
        case 'inactive':
            return 'bg-secondary';
        case 'admitted':
        case 'on leave':
            return 'bg-info';
        case 'completed':
            return 'bg-primary';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-warning';
    }
}

// Global variable for calendar
let currentWeekStart;


// Pharmacy Data (sample Ethiopian medicines)
let medicines = [
    { id: 1, name: "Amoxicillin 500mg", category: "antibiotics", price: 85.50, quantity: 150, expiry: "2024-06-30", description: "Broad-spectrum antibiotic" },
    { id: 2, name: "Artemether/Lumefantrine 20/120mg", category: "antimalarial", price: 45.00, quantity: 200, expiry: "2024-09-15", description: "For malaria treatment" },
    { id: 3, name: "Paracetamol 500mg", category: "painkillers", price: 12.75, quantity: 500, expiry: "2025-03-20", description: "Pain reliever and fever reducer" },
    { id: 4, name: "Metformin 500mg", category: "diabetes", price: 32.00, quantity: 120, expiry: "2024-11-30", description: "For type 2 diabetes" },
    { id: 5, name: "Losartan 50mg", category: "hypertension", price: 68.90, quantity: 80, expiry: "2024-08-15", description: "For high blood pressure" },
    { id: 6, name: "Ciprofloxacin 500mg", category: "antibiotics", price: 95.25, quantity: 90, expiry: "2024-05-31", description: "For bacterial infections" },
    { id: 7, name: "Doxycycline 100mg", category: "antibiotics", price: 55.00, quantity: 110, expiry: "2024-07-20", description: "For various bacterial infections" },
    { id: 8, name: "Ibuprofen 400mg", category: "painkillers", price: 18.50, quantity: 300, expiry: "2025-01-10", description: "NSAID pain reliever" },
    { id: 9, name: "Glibenclamide 5mg", category: "diabetes", price: 28.75, quantity: 95, expiry: "2024-10-31", description: "For type 2 diabetes" },
    { id: 10, name: "Hydrochlorothiazide 25mg", category: "hypertension", price: 42.00, quantity: 70, expiry: "2024-12-15", description: "Diuretic for high blood pressure" }
];

let cart = [];

// Initialize pharmacy page
function initializePharmacyPage() {
    loadMedicinesTable();
    setupMedicineForm();
    setupCart();

    // Search functionality
    document.getElementById('searchMedicineBtn').addEventListener('click', searchMedicines);
    document.getElementById('medicineSearch').addEventListener('keyup', function (e) {
        if (e.key === 'Enter') searchMedicines();
    });

    // Filter functionality
    document.getElementById('medicineCategoryFilter').addEventListener('change', function () {
        loadMedicinesTable(this.value, document.getElementById('medicineAvailabilityFilter').value);
    });

    document.getElementById('medicineAvailabilityFilter').addEventListener('change', function () {
        loadMedicinesTable(document.getElementById('medicineCategoryFilter').value, this.value);
    });

    // View cart button
    document.getElementById('viewCartBtn').addEventListener('click', function () {
        updateCartDisplay();
        const cartModal = new bootstrap.Modal(document.getElementById('shoppingCartModal'));
        cartModal.show();
    });

    // Payment method change
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', function () {
            document.getElementById('bankPaymentForm').style.display =
                (this.value === 'cbe' || this.value === 'abyssinia') ? 'block' : 'none';
        });
    });

    // Checkout button
    document.getElementById('checkoutBtn').addEventListener('click', processPayment);
}

function loadMedicinesTable(categoryFilter = 'all', availabilityFilter = 'all') {
    const tableBody = document.querySelector('#medicinesTable tbody');
    tableBody.innerHTML = '';

    let filteredMedicines = medicines;

    // Apply category filter
    if (categoryFilter !== 'all') {
        filteredMedicines = filteredMedicines.filter(m => m.category === categoryFilter);
    }

    // Apply availability filter
    if (availabilityFilter === 'in-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 20);
    } else if (availabilityFilter === 'low-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 0 && m.quantity <= 20);
    } else if (availabilityFilter === 'out-of-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity === 0);
    }

    filteredMedicines.forEach(medicine => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${medicine.id}</td>
            <td>${medicine.name}</td>
            <td>${formatCategory(medicine.category)}</td>
            <td>${medicine.price.toFixed(2)}</td>
            <td>
                <span class="badge ${getStockBadgeClass(medicine.quantity)}">
                    ${medicine.quantity > 0 ? medicine.quantity : 'Out of Stock'}
                </span>
            </td>
            <td>${formatDate(medicine.expiry)}</td>
            <td>
                <button class="btn btn-sm btn-success add-to-cart" data-id="${medicine.id}" ${medicine.quantity === 0 ? 'disabled' : ''}>
                    <i class="fas fa-cart-plus"></i> Add
                </button>
                <button class="btn btn-sm btn-primary view-medicine" data-id="${medicine.id}">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Add event listeners to buttons
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            addToCart(medicineId);
        });
    });

    document.querySelectorAll('.view-medicine').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            viewMedicineDetails(medicineId);
        });
    });
}

function setupMedicineForm() {
    // Save new medicine
    document.getElementById('saveMedicineBtn').addEventListener('click', saveNewMedicine);
}

function saveNewMedicine() {
    const name = document.getElementById('medicineName').value;
    const category = document.getElementById('medicineCategory').value;
    const price = parseFloat(document.getElementById('medicinePrice').value);
    const quantity = parseInt(document.getElementById('medicineQuantity').value);
    const expiry = document.getElementById('medicineExpiry').value;
    const description = document.getElementById('medicineDescription').value;

    if (!name || !category || isNaN(price) || isNaN(quantity) || !expiry) {
        alert('Please fill in all required fields');
        return;
    }

    // Generate new ID
    const newId = medicines.length > 0 ? Math.max(...medicines.map(m => m.id)) + 1 : 1;

    // Create new medicine
    const newMedicine = {
        id: newId,
        name,
        category,
        price,
        quantity,
        expiry,
        description: description || null
    };

    medicines.push(newMedicine);

    // Close modal and refresh table
    bootstrap.Modal.getInstance(document.getElementById('addMedicineModal')).hide();
    loadMedicinesTable();

    // Reset form
    document.getElementById('addMedicineForm').reset();
}

function viewMedicineDetails(medicineId) {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine) return;

    // You can implement a detailed view modal here
    alert(`Medicine Details:\n\nName: ${medicine.name}\nCategory: ${formatCategory(medicine.category)}\nPrice: ${medicine.price.toFixed(2)} ETB\nQuantity: ${medicine.quantity}\nExpiry: ${formatDate(medicine.expiry)}\nDescription: ${medicine.description || 'N/A'}`);
}

function searchMedicines() {
    const searchTerm = document.getElementById('medicineSearch').value.toLowerCase();
    const categoryFilter = document.getElementById('medicineCategoryFilter').value;
    const availabilityFilter = document.getElementById('medicineAvailabilityFilter').value;

    let filteredMedicines = medicines;

    // Apply search filter
    if (searchTerm) {
        filteredMedicines = filteredMedicines.filter(m =>
            m.name.toLowerCase().includes(searchTerm) ||
            (m.description && m.description.toLowerCase().includes(searchTerm)))
    }

    // Apply category filter
    if (categoryFilter !== 'all') {
        filteredMedicines = filteredMedicines.filter(m => m.category === categoryFilter);
    }

    // Apply availability filter
    if (availabilityFilter === 'in-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 20);
    } else if (availabilityFilter === 'low-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity > 0 && m.quantity <= 20);
    } else if (availabilityFilter === 'out-of-stock') {
        filteredMedicines = filteredMedicines.filter(m => m.quantity === 0);
    }

    const tableBody = document.querySelector('#medicinesTable tbody');
    tableBody.innerHTML = '';

    filteredMedicines.forEach(medicine => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${medicine.id}</td>
            <td>${medicine.name}</td>
            <td>${formatCategory(medicine.category)}</td>
            <td>${medicine.price.toFixed(2)}</td>
            <td>
                <span class="badge ${getStockBadgeClass(medicine.quantity)}">
                    ${medicine.quantity > 0 ? medicine.quantity : 'Out of Stock'}
                </span>
            </td>
            <td>${formatDate(medicine.expiry)}</td>
            <td>
                <button class="btn btn-sm btn-success add-to-cart" data-id="${medicine.id}" ${medicine.quantity === 0 ? 'disabled' : ''}>
                    <i class="fas fa-cart-plus"></i> Add
                </button>
                <button class="btn btn-sm btn-primary view-medicine" data-id="${medicine.id}">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Reattach event listeners
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            addToCart(medicineId);
        });
    });

    document.querySelectorAll('.view-medicine').forEach(btn => {
        btn.addEventListener('click', function () {
            const medicineId = parseInt(this.getAttribute('data-id'));
            viewMedicineDetails(medicineId);
        });
    });
}

// Cart Functions
function setupCart() {
    // Load cart from localStorage if available
    const savedCart = localStorage.getItem('pharmacyCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartCount();
    }
}

function addToCart(medicineId) {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine || medicine.quantity === 0) return;

    const existingItem = cart.find(item => item.id === medicineId);

    if (existingItem) {
        // Check if we have enough stock
        if (existingItem.quantity + 1 > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            return;
        }
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: medicine.id,
            name: medicine.name,
            price: medicine.price,
            quantity: 1
        });
    }

    updateCartCount();
    saveCartToStorage();

    // Show toast notification
    showToast(`${medicine.name} added to cart`, 'success');
}

function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = totalItems;
}

function updateCartDisplay() {
    const tableBody = document.querySelector('#cartTable tbody');
    tableBody.innerHTML = '';

    if (cart.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Your cart is empty</td></tr>';
        document.getElementById('cartSubtotal').textContent = '0.00 ETB';
        document.getElementById('cartTax').textContent = '0.00 ETB';
        document.getElementById('cartTotal').textContent = '0.00 ETB';
        return;
    }

    let subtotal = 0;

    cart.forEach(item => {
        const total = item.price * item.quantity;
        subtotal += total;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.price.toFixed(2)}</td>
            <td>
                <div class="input-group input-group-sm" style="width: 120px;">
                    <button class="btn btn-outline-secondary decrease-quantity" data-id="${item.id}" type="button">-</button>
                    <input type="number" class="form-control text-center" value="${item.quantity}" min="1" max="10" data-id="${item.id}">
                    <button class="btn btn-outline-secondary increase-quantity" data-id="${item.id}" type="button">+</button>
                </div>
            </td>
            <td>${total.toFixed(2)}</td>
            <td>
                <button class="btn btn-sm btn-danger remove-from-cart" data-id="${item.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    const tax = subtotal * 0.15; // 15% tax
    const total = subtotal + tax;

    document.getElementById('cartSubtotal').textContent = `${subtotal.toFixed(2)} ETB`;
    document.getElementById('cartTax').textContent = `${tax.toFixed(2)} ETB`;
    document.getElementById('cartTotal').textContent = `${total.toFixed(2)} ETB`;

    // Add event listeners to cart buttons
    document.querySelectorAll('.decrease-quantity').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            updateCartItemQuantity(itemId, -1);
        });
    });

    document.querySelectorAll('.increase-quantity').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            updateCartItemQuantity(itemId, 1);
        });
    });

    document.querySelectorAll('.remove-from-cart').forEach(btn => {
        btn.addEventListener('click', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            removeFromCart(itemId);
        });
    });

    document.querySelectorAll('#cartTable input[type="number"]').forEach(input => {
        input.addEventListener('change', function () {
            const itemId = parseInt(this.getAttribute('data-id'));
            const newQuantity = parseInt(this.value);
            updateCartItemQuantity(itemId, 0, newQuantity);
        });
    });
}

function updateCartItemQuantity(itemId, change, newQuantity = null) {
    const itemIndex = cart.findIndex(item => item.id === itemId);
    if (itemIndex === -1) return;

    const medicine = medicines.find(m => m.id === itemId);
    if (!medicine) return;

    if (newQuantity !== null) {
        // Direct quantity update
        if (newQuantity < 1) newQuantity = 1;
        if (newQuantity > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            newQuantity = medicine.quantity;
        }
        cart[itemIndex].quantity = newQuantity;
    } else {
        // Increment/decrement
        const newQty = cart[itemIndex].quantity + change;
        if (newQty < 1) return;
        if (newQty > medicine.quantity) {
            alert(`Only ${medicine.quantity} items available in stock`);
            return;
        }
        cart[itemIndex].quantity = newQty;
    }

    if (cart[itemIndex].quantity === 0) {
        cart.splice(itemIndex, 1);
    }

    updateCartCount();
    updateCartDisplay();
    saveCartToStorage();
}

function removeFromCart(itemId) {
    cart = cart.filter(item => item.id !== itemId);
    updateCartCount();
    updateCartDisplay();
    saveCartToStorage();
}

function saveCartToStorage() {
    localStorage.setItem('pharmacyCart', JSON.stringify(cart));
}

function processPayment() {
    const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;

    if (cart.length === 0) {
        alert('Your cart is empty');
        return;
    }

    if (paymentMethod === 'cbe' || paymentMethod === 'abyssinia') {
        const cardNumber = document.getElementById('cardNumber').value;
        const expiryDate = document.getElementById('expiryDate').value;
        const cvv = document.getElementById('cvv').value;
        const cardHolder = document.getElementById('cardHolder').value;

        if (!cardNumber || !expiryDate || !cvv || !cardHolder) {
            alert('Please fill in all payment details');
            return;
        }

        // Validate card number (simplified)
        if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
            alert('Please enter a valid 16-digit card number');
            return;
        }
    }

    // In a real app, you would send this to your payment processor
    // For this demo, we'll just show a success message

    // Generate receipt info
    const now = new Date();
    const transactionId = 'TRX-' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    const total = parseFloat(document.getElementById('cartTotal').textContent);

    document.getElementById('receiptTransactionId').textContent = transactionId;
    document.getElementById('receiptDate').textContent = now.toLocaleString('en-US', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
    document.getElementById('receiptMethod').textContent =
        paymentMethod === 'cash' ? 'Cash' :
            paymentMethod === 'cbe' ? 'CBE Birr' : 'Abyssinia Bank';
    document.getElementById('receiptAmount').textContent = total.toFixed(2) + ' ETB';

    // Update stock quantities
    cart.forEach(cartItem => {
        const medicine = medicines.find(m => m.id === cartItem.id);
        if (medicine) {
            medicine.quantity -= cartItem.quantity;
        }
    });

    // Clear cart
    cart = [];
    updateCartCount();
    saveCartToStorage();

    // Close cart modal and show success
    bootstrap.Modal.getInstance(document.getElementById('shoppingCartModal')).hide();

    // Show success modal after a short delay
    setTimeout(() => {
        const successModal = new bootstrap.Modal(document.getElementById('paymentSuccessModal'));
        successModal.show();
    }, 500);

    // Reload medicines table to reflect stock changes
    loadMedicinesTable();
}

// Utility Functions
function formatCategory(category) {
    const categories = {
        'antibiotics': 'Antibiotics',
        'antimalarial': 'Antimalarial',
        'painkillers': 'Painkillers',
        'diabetes': 'Diabetes',
        'hypertension': 'Hypertension',
        'other': 'Other'
    };
    return categories[category] || category;
}

function getStockBadgeClass(quantity) {
    if (quantity === 0) return 'bg-danger';
    if (quantity <= 20) return 'bg-warning text-dark';
    return 'bg-success';
}

function showToast(message, type = 'info') {
    // You can implement a proper toast notification here
    alert(`${type.toUpperCase()}: ${message}`);
}

// Update DOM Ready Function to include pharmacy initialization
document.addEventListener('DOMContentLoaded', function () {
    const path = window.location.pathname;
    const page = path.split("/").pop();

    if (page === "pharmacy.html") {
        initializePharmacyPage();
    }
    // ... rest of your existing code
});